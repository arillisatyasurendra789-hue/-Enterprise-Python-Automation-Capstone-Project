from app.logger import setup_logger
from app.cli import main

if __name__ == "__main__":
    setup_logger()
    main()
