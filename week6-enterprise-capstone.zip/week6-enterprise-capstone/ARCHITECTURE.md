# Architecture

```text
User
  |
  v
CLI / Scheduler
  |
  v
API Client
  |
  v
Data Processor (Pandas)
  |
  v
PDF Generator (ReportLab)
  |
  v
PDF Report

Logger monitors application execution.
```
