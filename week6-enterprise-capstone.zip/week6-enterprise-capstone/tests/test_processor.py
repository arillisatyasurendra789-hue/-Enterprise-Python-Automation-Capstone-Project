from app.processor import process_data

def test_process_data():
    data = [
        {"id": 1, "title": "Test", "body": "Sample"},
        {"id": 2, "title": "Test 2", "body": "Sample 2"},
    ]
    dataframe, statistics = process_data(data)
    assert statistics["total_records"] == 2
    assert len(dataframe) == 2
