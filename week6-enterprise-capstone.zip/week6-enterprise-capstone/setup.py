from setuptools import setup, find_packages

setup(
    name="enterprise-report-generator",
    version="1.0.0",
    description="Automated enterprise PDF report generator",
    packages=find_packages(),
    install_requires=["requests", "pandas", "reportlab", "apscheduler"],
    entry_points={"console_scripts": ["report-generator=app.cli:main"]},
)
