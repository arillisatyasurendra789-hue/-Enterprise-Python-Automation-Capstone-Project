# Enterprise Python Automation Capstone

## Project Overview
Automated enterprise PDF report generator that fetches REST API data, processes it with Pandas, generates a PDF using ReportLab, and supports CLI, scheduling, logging, testing, and packaging.

## Features
- REST API integration
- Data processing and statistics
- Professional PDF report generation
- CLI using argparse
- Automated scheduling with APScheduler
- Logging
- Unit testing with Pytest
- Python packaging

## Installation
```bash
pip install -r requirements.txt
pip install -e .
```

## CLI Usage
```bash
report-generator --url https://jsonplaceholder.typicode.com/posts
```

Or:
```bash
python -m app.cli --url https://jsonplaceholder.typicode.com/posts --output reports/final_report.pdf
```

## Testing
```bash
pytest
```

## Scheduling
Use `app.scheduler.start_scheduler()` to run reports automatically at a configured interval.

## Project Structure
See `ARCHITECTURE.md` and the repository folders for the modular structure.
