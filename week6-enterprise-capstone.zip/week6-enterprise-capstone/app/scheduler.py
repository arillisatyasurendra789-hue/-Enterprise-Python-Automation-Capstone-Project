from apscheduler.schedulers.blocking import BlockingScheduler
from app.cli import main

def start_scheduler(interval_minutes=60):
    scheduler = BlockingScheduler()
    scheduler.add_job(main, "interval", minutes=interval_minutes)
    print("Report scheduler started.")
    try:
        scheduler.start()
    except KeyboardInterrupt:
        scheduler.shutdown()
        print("Scheduler stopped.")
