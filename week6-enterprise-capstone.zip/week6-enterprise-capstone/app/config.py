import json
from pathlib import Path

def load_config(path="config.json"):
    with open(path, "r", encoding="utf-8") as file:
        return json.load(file)
