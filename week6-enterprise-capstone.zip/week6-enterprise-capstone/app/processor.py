import pandas as pd

def process_data(data):
    df = pd.DataFrame(data)
    statistics = {
        "total_records": len(df),
        "columns": list(df.columns),
    }

    if "price" in df.columns:
        statistics.update({
            "average_price": df["price"].mean(),
            "minimum_price": df["price"].min(),
            "maximum_price": df["price"].max(),
        })

    return df, statistics
