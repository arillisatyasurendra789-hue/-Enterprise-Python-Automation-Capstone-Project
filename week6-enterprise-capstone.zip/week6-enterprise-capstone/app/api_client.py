import requests

class APIClient:
    def __init__(self, base_url):
        self.base_url = base_url

    def fetch_data(self):
        response = requests.get(self.base_url, timeout=10)
        response.raise_for_status()
        return response.json()
