from datetime import datetime
from pathlib import Path
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle

def generate_pdf(dataframe, statistics, output_file):
    Path(output_file).parent.mkdir(parents=True, exist_ok=True)
    document = SimpleDocTemplate(output_file, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = [
        Paragraph("Enterprise Data Analysis Report", styles["Title"]),
        Spacer(1, 20),
        Paragraph(
            f"Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            styles["Normal"],
        ),
        Spacer(1, 20),
    ]

    summary_data = [["Metric", "Value"], ["Total Records", str(statistics["total_records"])]]
    for key in ("average_price", "minimum_price", "maximum_price"):
        if key in statistics:
            summary_data.append([key.replace("_", " ").title(), f"{statistics[key]:.2f}"])

    table = Table(summary_data)
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 1),
        ("PADDING", (0, 0), (-1, -1), 6),
    ]))
    elements += [table, Spacer(1, 20)]

    table_data = [list(dataframe.columns)]
    for row in dataframe.head(10).itertuples(index=False, name=None):
        table_data.append([str(value) for value in row])

    data_table = Table(table_data, repeatRows=1)
    data_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.grey),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5),
        ("FONTSIZE", (0, 0), (-1, -1), 7),
    ]))
    elements.append(data_table)
    document.build(elements)
