import argparse
import logging

from app.api_client import APIClient
from app.processor import process_data
from app.report_generator import generate_pdf
from app.config import load_config

def main(argv=None):
    config = load_config()
    parser = argparse.ArgumentParser(description="Enterprise PDF Report Generator")
    parser.add_argument("--url", default=config["api_url"], help="API endpoint")
    parser.add_argument(
        "--output",
        default=f"{config['report_directory']}/report.pdf",
        help="Output PDF path",
    )
    args = parser.parse_args(argv)

    logger = logging.getLogger(__name__)
    logger.info("Fetching API data")
    data = APIClient(args.url).fetch_data()
    dataframe, statistics = process_data(data)
    logger.info("Data processing completed")
    generate_pdf(dataframe, statistics, args.output)
    logger.info("PDF report generated")
    print(f"Report generated: {args.output}")

if __name__ == "__main__":
    main()
